create view VIEW1 as
  select id,name,score from tb_student with read only
/

