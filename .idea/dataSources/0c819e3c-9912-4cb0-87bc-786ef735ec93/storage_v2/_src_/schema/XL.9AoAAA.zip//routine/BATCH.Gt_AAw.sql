create procedure batch
is
  v_id varchar2(32);
  v_password varchar2(32);
  v_created timestamp;
  begin
    select systimestamp into v_created from dual;
    for i in 1..100
    loop
      v_id := sys_guid();
      v_password := substr(v_id,5,8);
      v_created := v_created + 1/17280;
     insert into t_users values(v_id,v_password, v_created);
    end loop;
  commit;
  end;

/

